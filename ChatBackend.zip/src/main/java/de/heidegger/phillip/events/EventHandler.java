package de.heidegger.phillip.events;

public interface EventHandler {

    boolean handle(Object event);

}
