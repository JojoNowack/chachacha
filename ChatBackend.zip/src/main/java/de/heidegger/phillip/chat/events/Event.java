package de.heidegger.phillip.chat.events;

public interface Event {
}
