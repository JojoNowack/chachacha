package de.heidegger.phillip.chat.server;

public interface ChatServerTrustedAPI extends ChatServerPublicAPI, ChatServerUserManagement, ChatServerRoomManagement {

}
